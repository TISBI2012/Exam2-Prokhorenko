﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EXAM2Prokhorenko.Models;

namespace EXAM2Prokhorenko.Pages
{
    /// <summary>
    /// Логика взаимодействия для OwnerSetChangesPizzaPage.xaml
    /// </summary>
    public partial class OwnerSetChangesPizzaPage : Page
    {
        Pizza contextPizza;
        public OwnerSetChangesPizzaPage(Pizza pizza)
        {
            InitializeComponent();
            contextPizza = pizza;
            DataContext = contextPizza;
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            if (contextPizza.id == 0)
                App.DB.Pizza.Add(contextPizza);
            App.DB.SaveChanges();
            NavigationService.GoBack();
        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
