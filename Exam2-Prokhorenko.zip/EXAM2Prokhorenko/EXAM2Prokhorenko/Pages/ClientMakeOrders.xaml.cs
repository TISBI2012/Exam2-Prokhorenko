﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EXAM2Prokhorenko.Models;

namespace EXAM2Prokhorenko.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientMakeOrders.xaml
    /// </summary>
    public partial class ClientMakeOrders : Page
    {
        Order contextOrder;   
        public ClientMakeOrders()
        {
            InitializeComponent();
            CBPizza.ItemsSource = App.DB.Pizza.ToList();
            contextOrder = new Order();
            DataContext = contextOrder;
            contextOrder.User = App.LoggedUser;
        }

        private void BAddPizza_Click(object sender, RoutedEventArgs e)
        {
            var selectedPizza = CBPizza.SelectedItem as Pizza;
            var orderPizza = new OrderPizza();
            orderPizza.Pizza = selectedPizza;
            contextOrder.OrderPizza.Add(orderPizza);
            DGMyOrders.ItemsSource = contextOrder.OrderPizza.ToList();
        }

        private void BCreateOrder_Click(object sender, RoutedEventArgs e)
        {
            contextOrder.Date = DateTime.Now.ToString();
            App.DB.Order.Add(contextOrder);
            App.DB.SaveChanges();
            NavigationService.GoBack();
        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
