﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EXAM2Prokhorenko.Pages
{
    /// <summary>
    /// Логика взаимодействия для LogPage.xaml
    /// </summary>
    public partial class LogPage : Page
    {
        public LogPage()
        {
            InitializeComponent();
        }

        private void BSignIn_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLog.Text;
            string password = TBPass.Text;

            var loggedUser = App.DB.User.FirstOrDefault(x => x.Login == login && x.Password == password);

            if(loggedUser == null)
            {
                MessageBox.Show("InValid Login or Password");
                return;
            }
            if (loggedUser.Role_id == 1)
                NavigationService.Navigate(new ClientMainPage());
            if (loggedUser.Role_id == 2) 
                NavigationService.Navigate(new CoockerMainPage());
            if (loggedUser.Role_id == 3)
                NavigationService.Navigate(new ManagerMainPage());
            if (loggedUser.Role_id == 4)
                NavigationService.Navigate(new OwnerMainPage());
            MessageBox.Show("You are logged");
                return;
            App.LoggedUser = loggedUser;
        }
    }
}
