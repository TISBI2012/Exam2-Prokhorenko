﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EXAM2Prokhorenko.Models;

namespace EXAM2Prokhorenko.Pages
{
    /// <summary>
    /// Логика взаимодействия для OwnerPizzaPage.xaml
    /// </summary>
    public partial class OwnerPizzaPage : Page
    {
        public OwnerPizzaPage()
        {
            InitializeComponent();
            DGPizza.ItemsSource = App.DB.Pizza.ToList();
        }

        private void BAddPizza_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OwnerSetChangesPizzaPage(new Pizza()));
        }

        private void BEditPizza_Click(object sender, RoutedEventArgs e)
        {
            var selectedPizza = DGPizza.SelectedItem as Pizza;
            if(selectedPizza == null)
            {
                  MessageBox.Show("You should to select pizza!");
                    return;
            }
            NavigationService.Navigate(new OwnerSetChangesPizzaPage(selectedPizza));
        }

        private void BRemovePizza_Click(object sender, RoutedEventArgs e)
        {
            var selectedPizza = DGPizza.SelectedItem as Pizza;
            if (selectedPizza == null)
            {
                MessageBox.Show("You should to select pizza!");
                return;
            }
            selectedPizza = null;
        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
